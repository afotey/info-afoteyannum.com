import React, { useMemo, useState, useEffect } from "react";
import axios from "axios";

import Table from "./Table";
import "./App.css";

const Genres = ({ values }) => {
  return (
    <>
      {values.map((genre, idx) => {
        return (
          <span key={idx} className="badge">
            {genre}
          </span>
        );
      })}
    </>
  );
};

function App() {
  const columns = useMemo(
    () => [
      {
        Header: "PDF Name/Amount",
        columns: [
          {
            Header: "Name",
            accessor: "name"
          },
          {
            Header: "Final",
            accessor: "final"
          },
          {
            Header: "Date",
            accessor: "date"
          },
          {
            Header: "Contract Number",
            accessor: "ContractNumber"
          }
        ]
      },
      {
        Header: "Details",
        columns: [
          {
            Header: "Business Name",
            accessor: "business_name"
          },
          {
            Header: "Payable To",
            accessor: "payable_to_name"
          },
          {
            Header: "Phone",
            accessor: "phone_number"
          },
          {
            Header: "Email",
            accessor: "e_mail"
          },
          {
            Header: "Business Address",
            accessor: "businessaddress"
          },
        ]
      }
    ],
    []
  );

  const [data, setData] = useState([]);

  useEffect(() => {
    (async () => {
      const result = await axios("pdfData.json");
      setData(result.data);
    })();
  }, []);

  return (
    <div className="App">
      <Table columns={columns} data={data} />
    </div>
  );
}

export default App;
