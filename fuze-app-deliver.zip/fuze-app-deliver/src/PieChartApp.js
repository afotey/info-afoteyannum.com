import React from 'react';
import axios from 'axios';  
import {Pie, Doughnut} from 'react-chartjs-2';


export default class PieChart extends React.Component {
  constructor(props) {  
    super(props);  
    this.state = { Data: {} };  
  }

  componentDidMount() {  
    axios.get('pdfData.json')  
      .then(res => {  
              console.log(res);  
              const ipl = res.data;  
              let playername = [];  
              let runscore = [];  
              ipl.forEach(record => {  
                playername.push(record.name);  
                runscore.push(record.status);  
              });  
              this.setState({  
                Data: {  
                  labels: playername,  
                  datasets: [  
                    {  
                      label: 'PDF Invoicing Status',  
                      data: runscore,  
                      backgroundColor: [  
                        "#3cb371",  
                        "#0000FF",  
                        "#9966FF",  
                        "#4C4CFF",  
                        "#00FFFF",  
                        "#f990a7",  
                        "#aad2ed",  
                        "#FF00FF",  
                        "Blue",  
                        "Red"  
                      ]  
                    }  
                  ]  
                }  
              });  
        })  
    }  

  render() {
    return (
      <div>
        <Pie
            data={this.state.Data}
            // width={200}
            height={50}
            options={{
                // maintainAspectRatio: true,
                title:{
                    display:true,
                    text:'Average PDF Invoices',
                    fontSize:15
                },
                    legend:{
                    display:true,
                    position:'bottom'
                }
            }}
        />

      </div>
    );
  }
}
