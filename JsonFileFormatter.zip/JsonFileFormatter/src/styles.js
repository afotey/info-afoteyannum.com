const styles = {
  color: "blue",
  backgroundImage: "url(" + imgUrl + ")",
};
