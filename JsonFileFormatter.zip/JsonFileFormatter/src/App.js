import React from "react";
import ReactTable from "react-table-6";
import data from "../files/mainFile.json";
import Modal from "react-modal";

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
  },
};
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: data,
      selectedDate: new Date(),
      filterData: null,
      showModal: false,
      selectedData: {},
    };
    this.handleOpenModal = this.handleOpenModal.bind(this);
    this.handleCloseModal = this.handleCloseModal.bind(this);
    this.FilterInformation = this.FilterInformation.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.getData = this.getData.bind(this);
    this.resetSearch = this.resetSearch.bind(this);
    this.filterDate = this.filterDate.bind(this);
    this.filterDateView = this.filterDateView.bind(this);
    this.changeInputValue = this.changeInputValue.bind(this);
  }

  FilterInformation() {
    this.setState({ filterData: this.state.selectedDate });
  }

  handleOpenModal(data) {
    let mainDatea = data.row._original;
    mainDatea.entity_date = this.filterDate(mainDatea.entity_date);
    this.setState({ showModal: true, selectedData: mainDatea });
    console.log(this.state.selectedData, data.row._original);
    document.getElementById("myDate").value = "2020-03-02";
  }

  handleCloseModal() {
    this.setState({ showModal: false });
  }
  handleChange(event) {
    this.setState({ selectedDate: event.target.value });
  }
  getData() {
    if (this.state.filterData) {
      return this.state.data.filter(
        (x) => x.processed_date == this.state.filterData
      );
    } else {
      return this.state.data;
    }
  }
  resetSearch() {
    this.setState({ selectedDate: new Date(), filterData: null });
  }
  filterDate(data) {
    let date = new Date(data);
    let newDate = `${date.getFullYear()}-${date.getMonth() < 10 ? 0 : ""}${
      date.getMonth() + 1
    }-${date.getDate() < 10 ? 0 : ""}${date.getDate()}`;
    console.log(data, newDate);
    return newDate ? newDate : "2020/03/01";
  }
  filterDateView(data) {
    let date = new Date(data);
    let newDate = `${
      date.getMonth() + 1
    }/${date.getDate()}/${date.getFullYear()}`;
    console.log(data, newDate);
    return newDate ? newDate : "2020/03/01";
  }

  changeInputValue(entity, value) {
    let inputValue = value.target.value;
    let selectedValue = this.state.selectedData;
    selectedValue[entity] = inputValue;
    this.setState({ selectedData: selectedValue });
  }
  render() {
    const columns = [
      {
        Header: "Date",
        accessor: "entity_date",
        Cell: (props) => this.filterDateView(props.value),
      },
      {
        Header: "Date Confidence",
        accessor: "entity_date_confidence",
      },
      {
        id: "friendName", // Required because our accessor is not a string
        Header: "Total Amount",
        accessor: "entity_total_amount",
      },
      {
        Header: "Total Amount Confidence", // Custom header components!
        accessor: "entity_total_amount_confidence",
      },
      {
        Header: "Business Name", // Custom header components!
        accessor: "entity_business_name",
      },
      {
        Header: "Business Address", // Custom header components!
        accessor: "entity_business_name_confidence",
      },
      {
        Header: "Business Address Confidence", // Custom header components!
        accessor: "entity_business_address",
      },
      {
        Header: "Contractnbr", // Custom header components!
        accessor: "entity_business_address_confidence",
      },
      {
        Header: "Contractnbr Confidence", // Custom header components!
        accessor: "entity_contractnbr",
      },
      {
        Header: "Processed Date", // Custom header components!
        accessor: "processed_date",
      },
    ];
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <a className="navbar-brand" href="#">
            Json Formatter
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto"></ul>
            <div className="form-inline my-2 my-lg-0">
              <input
                type="date"
                className="form-control mr-sm-2"
                placeholder="Search"
                aria-label="Search"
                value={this.state.selectedDate}
                onChange={this.handleChange}
              />
              <button
                className="btn btn-outline-success my-2 my-sm-0"
                onClick={() => this.FilterInformation()}
              >
                Get Information
              </button>
              <button
                className="btn btn-outline-warning my-2 my-sm-0 ml-2"
                onClick={() => this.resetSearch()}
              >
                Reset
              </button>
            </div>
          </div>
        </nav>
        <div>
          <ReactTable
            data={this.getData()}
            columns={columns}
            filterable={true}
            getTdProps={(state, rowInfo, column, instance) => {
              return {
                onClick: (e, handleOriginal) => {
                  this.handleOpenModal(rowInfo);
                },
              };
            }}
          />
        </div>
        <Modal
          isOpen={this.state.showModal}
          style={customStyles}
          contentLabel="Minimal Modal Example"
        >
          <button onClick={this.handleCloseModal}>Close Modal</button>
          <div className="d-flex">
            <div>
              <img src="../files/pdf_image.png" />
            </div>
            <div style={InputSetion}>
              <div class="form-group">
                <label>Entity Date</label>
                <input
                  id="myDate"
                  value={this.state.selectedData.entity_date}
                  datepicker
                  filter="date"
                  type="date"
                  class="form-control"
                  onChange={(e) => this.changeInputValue("entity_date", e)}
                />
              </div>
              <div class="form-group">
                <label>Entity Total Amount</label>
                <input
                  value={this.state.selectedData.entity_total_amount}
                  datepicker
                  filter="date"
                  type="text"
                  class="form-control"
                  onChange={(e) =>
                    this.changeInputValue("entity_total_amount", e)
                  }
                />
              </div>
              <div class="form-group">
                <label>Entity Business Name</label>
                <input
                  value={this.state.selectedData.entity_business_name}
                  datepicker
                  filter="date"
                  type="text"
                  class="form-control"
                  onChange={(e) =>
                    this.changeInputValue("entity_business_name", e)
                  }
                />
              </div>
              <div class="form-group">
                <label>Entity Business Address</label>
                <input
                  value={this.state.selectedData.entity_business_address}
                  datepicker
                  filter="date"
                  type="text"
                  class="form-control"
                  onChange={(e) =>
                    this.changeInputValue("entity_business_address", e)
                  }
                />
              </div>
              <div class="form-group">
                <label> Entity Contract Number</label>
                <input
                  value=""
                  datepicker
                  filter="date"
                  type="text"
                  class="form-control"
                />
              </div>
              <button
                type="submit"
                class="btn btn-primary w-100"
                onClick={() => this.setState({ showModal: false })}
              >
                Update Information
              </button>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}

// const App = () => (
//   <div className={"col-md-12"}>
//     <h1>Minimalastic React Boilerplate</h1>
//   </div>
// );

export default App;

const InputSetion = {
  margin: "20px",
  width: "250px",
};
